@echo off
chcp 65001 >nul
title Actualizar indice de normativa - Grupo Alaris
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Actualizar-indice.ps1"
echo.
pause
