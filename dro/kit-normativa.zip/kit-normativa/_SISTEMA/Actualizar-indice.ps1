﻿<#
    Actualizar-indice.ps1
    Grupo Alaris - Cuaderno del DRO

    Qué hace:
      1. Crea la estructura de carpetas si no existe.
      2. Acomoda por primera vez los PDF que estén sueltos en la raíz, según el mapa de abajo.
      3. Recorre las carpetas y escribe _SISTEMA\indice.js, que es lo que lee el Cuaderno.

    No borra nada. Los archivos que no reconoce los deja donde están y los reporta al final.
    Ejecútalo cada vez que agregues o quites un documento.
#>

$ErrorActionPreference = 'Stop'
$RAIZ = Split-Path -Parent $PSScriptRoot
Write-Host ""
Write-Host "  Carpeta de normativa: $RAIZ" -ForegroundColor Cyan
Write-Host ""

# ---------------------------------------------------------------- estructura
$carpetas = @(
    '_GENERALES',
    '_ESTATAL',
    '_ESTATAL\puebla',
    '_REFERENCIA',
    'MUNICIPIOS',
    'MUNICIPIOS\_PLANTILLA',
    'MUNICIPIOS\puebla',
    'MUNICIPIOS\puebla\_historico',
    'MUNICIPIOS\san-andres-cholula',
    'MUNICIPIOS\san-pedro-cholula',
    'MUNICIPIOS\cuautlancingo',
    'MUNICIPIOS\atlixco',
    'MUNICIPIOS\tehuacan'
)
foreach ($c in $carpetas) {
    $p = Join-Path $RAIZ $c
    if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null; Write-Host "  + carpeta  $c" -ForegroundColor DarkGray }
}

# ------------------------------------------------- acomodo inicial de la raíz
$mapa = @{
    'Codigo_de_Edificacion_de_Vivienda.pdf'                                                                  = '_GENERALES'
    'Criterios_Vivienda_Adecuada.pdf'                                                                        = '_GENERALES'
    'LViv.pdf'                                                                                               = '_GENERALES'
    'Ley_de_Fraccionamientos_y_Acciones_Urbanisticas_del_Estado_Libre_y_Soberano__de_Puebla_T8_05042024.pdf'  = '_ESTATAL\puebla'
    'Ley_de_Movilidad_y_Seguridad_Vial_del_Estado_de_Puebla_EV_18062025.pdf'                                  = '_ESTATAL\puebla'
    'COREMUN 10 DE DICIEMBRE DE 2025.pdf'                                                                    = 'MUNICIPIOS\puebla'
    'COREMUN 10 DE DICIEMBRE DE 2025 solo obra.pdf'                                                          = 'MUNICIPIOS\puebla'
    'coremun abril 2025.pdf'                                                                                 = 'MUNICIPIOS\puebla\_historico'
    'NORMA TÉCNICA COMPLEMENTARIA PARA EL PROYECTO ARQUITECTÓNICO.pdf'                                       = '_REFERENCIA'
}
$movidos = 0
foreach ($archivo in $mapa.Keys) {
    $origen = Join-Path $RAIZ $archivo
    if (Test-Path $origen) {
        $destino = Join-Path (Join-Path $RAIZ $mapa[$archivo]) $archivo
        if (-not (Test-Path $destino)) {
            Move-Item -LiteralPath $origen -Destination $destino
            Write-Host ("  > movido    {0}  ->  {1}" -f $archivo, $mapa[$archivo]) -ForegroundColor Green
            $movidos++
        }
    }
}

# --------------------------------------------------------------- utilidades
$titulosPath = Join-Path $PSScriptRoot 'titulos.json'
$titulos = @{}
if (Test-Path $titulosPath) {
    $j = Get-Content -LiteralPath $titulosPath -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($p in $j.PSObject.Properties) { if ($p.Name -ne '_comentario') { $titulos[$p.Name] = $p.Value } }
}

function Leer-Documentos([string]$carpetaRelativa) {
    $abs = Join-Path $RAIZ $carpetaRelativa
    $salida = @()
    if (-not (Test-Path $abs)) { return ,$salida }
    $archivos = Get-ChildItem -LiteralPath $abs -File | Where-Object { $_.Extension -match '^\.(pdf|docx?|xlsx?|txt)$' } | Sort-Object Name
    foreach ($a in $archivos) {
        $meta = $titulos[$a.Name]
        $salida += [ordered]@{
            archivo   = $a.Name
            titulo    = if ($meta -and $meta.titulo)  { $meta.titulo }  else { [System.IO.Path]::GetFileNameWithoutExtension($a.Name) }
            emisor    = if ($meta -and $meta.emisor)  { $meta.emisor }  else { '' }
            vigencia  = if ($meta -and $meta.vigencia){ $meta.vigencia }else { '' }
            nota      = if ($meta -and $meta.nota)    { $meta.nota }    else { '' }
            principal = [bool]($meta -and $meta.principal)
            historico = [bool]($meta -and $meta.historico)
            ruta      = ($carpetaRelativa + '\' + $a.Name).Replace('\','/')
            mb        = [math]::Round($a.Length / 1MB, 1)
        }
    }
    return ,$salida
}

function Leer-Ficha([string]$carpetaMunicipio) {
    $f = Join-Path $carpetaMunicipio 'ficha.json'
    if (Test-Path $f) {
        try { return (Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { Write-Host "  ! ficha.json ilegible en $carpetaMunicipio" -ForegroundColor Yellow }
    }
    return $null
}

# ------------------------------------------------------------------- índice
$indice = [ordered]@{
    generado   = (Get-Date).ToString('yyyy-MM-dd HH:mm')
    raiz       = $RAIZ
    generales  = Leer-Documentos '_GENERALES'
    referencia = Leer-Documentos '_REFERENCIA'
    estatal    = [ordered]@{}
    municipios = [ordered]@{}
}

Get-ChildItem -LiteralPath (Join-Path $RAIZ '_ESTATAL') -Directory | Sort-Object Name | ForEach-Object {
    $indice.estatal[$_.Name] = Leer-Documentos ('_ESTATAL\' + $_.Name)
}

Get-ChildItem -LiteralPath (Join-Path $RAIZ 'MUNICIPIOS') -Directory | Sort-Object Name | ForEach-Object {
    if ($_.Name -eq '_PLANTILLA') { return }
    $rel   = 'MUNICIPIOS\' + $_.Name
    $ficha = Leer-Ficha $_.FullName
    $docs  = Leer-Documentos $rel
    $hist  = Leer-Documentos ($rel + '\_historico')
    $indice.municipios[$_.Name] = [ordered]@{
        clave     = $_.Name
        nombre    = if ($ficha -and $ficha.municipio) { $ficha.municipio } else { $_.Name }
        estado    = if ($ficha -and $ficha.estado)    { $ficha.estado }    else { '' }
        completa  = [bool]($ficha -and $ficha.completa)
        ficha     = $ficha
        normas    = $docs
        historico = $hist
    }
}

$json = $indice | ConvertTo-Json -Depth 12 -Compress:$false
$js   = "/* Generado por Actualizar-indice.ps1 el " + $indice.generado + ". No editar a mano. */" + [Environment]::NewLine +
        "window.NORMATIVA = " + $json + ";" + [Environment]::NewLine
$destinoJs = Join-Path $PSScriptRoot 'indice.js'
[System.IO.File]::WriteAllText($destinoJs, $js, (New-Object System.Text.UTF8Encoding($false)))

# ------------------------------------------------------------------ reporte
$nGen = @($indice.generales).Count
$nRef = @($indice.referencia).Count
$nMun = 0; $sinFicha = @()
foreach ($k in $indice.municipios.Keys) {
    $nMun += @($indice.municipios[$k].normas).Count
    if (-not $indice.municipios[$k].completa) { $sinFicha += $indice.municipios[$k].nombre }
}
Write-Host ""
Write-Host "  Indice actualizado." -ForegroundColor Green
Write-Host ("    generales   {0}" -f $nGen)
Write-Host ("    estatales   {0}" -f (($indice.estatal.Keys | ForEach-Object { @($indice.estatal[$_]).Count } | Measure-Object -Sum).Sum))
Write-Host ("    municipales {0}  en {1} municipios" -f $nMun, $indice.municipios.Count)
Write-Host ("    referencia  {0}" -f $nRef)
if ($movidos -gt 0) { Write-Host ("    se acomodaron {0} archivos que estaban en la raiz" -f $movidos) -ForegroundColor Green }

$sueltos = Get-ChildItem -LiteralPath $RAIZ -File | Where-Object { $_.Extension -match '^\.(pdf|docx?|xlsx?)$' }
if ($sueltos) {
    Write-Host ""
    Write-Host "  Estos archivos siguen sueltos en la raiz. Muevelos a la carpeta que corresponda:" -ForegroundColor Yellow
    $sueltos | ForEach-Object { Write-Host ("    - " + $_.Name) -ForegroundColor Yellow }
}
if ($sinFicha) {
    Write-Host ""
    Write-Host "  Municipios con ficha incompleta (el Cuaderno te va a advertir antes de firmar ahi):" -ForegroundColor Yellow
    $sinFicha | ForEach-Object { Write-Host ("    - " + $_) -ForegroundColor Yellow }
}
Write-Host ""
Write-Host "  Abre Cuaderno_DRO_Alaris.html y ve a la pestana Normativa." -ForegroundColor Cyan
Write-Host ""
